# Minimal FastAPI example

This code contains an example of a simple FastAPI app integrated with Sentry for tracking errors. It is intended to be reviewed alongside the lecture "Serving ML models with APIs".

To run the proyect install FastAPI: `pip install fastapi[standard] sentry-sdk[fastapi]` and run the app using `fastapi dev main.py`.

Make sure to replace the `SENTRY_DSN` in the code with your own DSN.

This code contains no UI as methods are expected to be accessed through the browser and through FastAPI's docs as explained in the lecture.

After having the app running, try some request to the endpoint `/sentry-debug` to generate an error and see how it is tracked in Sentry. Also, try using the `/operation` endpoint with an invalid operation or trying to do division by zero.
