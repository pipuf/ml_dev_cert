# Minimal FastAPI example

This code contains an example of a simple FastAPI app. It is intended to be reviewed alongside the lecture "Serving ML models with APIs".

To run the proyect install FastAPI: `pip install fastapi` and run the app using `fastapi dev main.py`.

This code contains no UI as methods are expected to be accessed through the browser and through FastAPI's docs as explained in the lecture.
