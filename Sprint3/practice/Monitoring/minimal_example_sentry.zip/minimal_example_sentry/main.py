from fastapi import FastAPI
from routes.api import router
import sentry_sdk


SENTRY_DSN = "https://46b1c537fa2a854451f078f12c16b074@o4507941424922624.ingest.us.sentry.io/4507941432655872"

# We have to initialize the Sentry SDK only once, when the application starts.
# Then we can use sentry_sdk package anywhere in the project.
sentry_sdk.init(
    dsn=SENTRY_DSN,
    # Set traces_sample_rate to 1.0 to capture 100%
    # of transactions for tracing.
    traces_sample_rate=1.0,
    # Set profiles_sample_rate to 1.0 to profile 100%
    # of sampled transactions.
    # We recommend adjusting this value in production.
    profiles_sample_rate=1.0,
)


app = FastAPI()
app.include_router(router)


@app.get("/")
def root():
    return {"message": "Hello, World!"}


# test it by passing parameters through url: http://127.0.0.1:8000/add/1/2
@app.get("/add/{num1}/{num2}")
def add_url(num1: int, num2: int):
    """This function takes two url parameters, num1 and num2, and returns a dictionary with the key "sum" and the value of the sum of both."""
    return {"sum": num1 + num2}


# test it by passing query parameters: http://127.0.0.1:8000/add?num1=1&num2=2
@app.get("/add")
def add_get(num1: int, num2: int):
    """This function takes two query parameters, num1 and num2, and returns a dictionary with the key "sum" and the value of the sum of both."""
    return {"sum": num1 + num2}


@app.get("/sentry-debug")
async def trigger_error():
    division_by_zero = 1 / 0
